1. Run Main File named as "TechGig_RoboMaster.xaml".

2.For running this Workflow you have to send email to robot for asking services.

3. Email Subject should be "Service Type <Name Of Service>" .

Example :- Service Type Doctor

4.For Practo Workflow enter Credentials.

5. Video is available in "Video Folder".

6. Presentation is available in "Presentation Folder".